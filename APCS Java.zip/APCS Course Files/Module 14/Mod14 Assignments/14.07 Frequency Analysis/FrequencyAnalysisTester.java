
/**
 * This tests the Frequency Analysis Tester
 * 
 * @Catherine Zeng 
 * @2-25-14
 */
import java.io.IOException;
import java.util.Scanner;
public class FrequencyAnalysisTester
{
   public static void main(String[] args) throws IOException
   {
       FrequencyAnalysis.normalAlphabetFrequency();
       FrequencyAnalysis.cipherTextFrequency();
    }
}
