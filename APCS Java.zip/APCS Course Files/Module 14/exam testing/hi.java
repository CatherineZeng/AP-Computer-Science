
/**
 * Write a description of class hi here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class hi
{
    // instance variables - replace the example below with your own
    private int x;
 
}
