
/**
 * This program creates a ASCII Art stick figure.
 * Notice when the escape character had to be used.
 * 
 * �FLVS 2007
 * @author anonymous 
 * @version 03/01/07
 */
public class Picture
{
    public static void main(String[ ] args)
    {
        System.out.println("              __|__");
        System.out.println("             / * * \\");
        System.out.println("            /   ^   \\");
        System.out.println("            \\ ----- /");
        System.out.println("             \\_____/");
        System.out.println("                |");
        System.out.println("                |");
        System.out.println("          ------|------");
        System.out.println("                |");
        System.out.println("                |");
        System.out.println("                |");
        System.out.println("                |");
        System.out.println("                |");
        System.out.println("               / \\");
        System.out.println("              /   \\");
        System.out.println("             /     \\");
        System.out.println("            /       \\");
        System.out.println("           /         \\");
	    
	}//end of main method
}//end of class
