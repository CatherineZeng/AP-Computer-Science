
/**
 * Write a description of class AsciiArt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AsciiArt
{
    public static void main(String [] args)
    {
    //local variables
   