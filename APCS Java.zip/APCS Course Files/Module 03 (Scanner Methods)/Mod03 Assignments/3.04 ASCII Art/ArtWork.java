
/**
 * Catherine Zeng 7-8-13
 *The purpose of this program is to create an awesome smiley 
 *
 */
public class ArtWork
{
    public static void main(String [ ] args)
    {
    //variables
    String row1=" \\    /";
    String row2="  \\  / ";
    String row3="  O  O";
    String row4="   ||";
    String row5="   ||";
    String row6="   ||";
    String row7="  (__)";
    String row8="\\      /";
    String row9=" \\    /";
    String row10="  \\__/";
    String row11="Smiley created by Catherine Zeng";
    
    
    
    //print the art
    System.out.print(row1+"\n"+row2+"\n"+row3+"\n"+row4+"\n"+row5+"\n"+row6+"\n"+row7+"\n"+row8+"\n"+row9+"\n"+row10+"\n\n"+row11);
    }
}
