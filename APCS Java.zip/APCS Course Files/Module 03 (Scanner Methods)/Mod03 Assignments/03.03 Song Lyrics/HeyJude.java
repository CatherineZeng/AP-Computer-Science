
/**
 * Write a description of class HeyJude here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HeyJude
{
    public static void main(String [ ] args)
    {
    String title="       Hey Jude";
    String singer="       The Beatles";
    String separater="*************************************";
    
    //print APCS art
    System.out.println(title);
    System.out.println(singer);
    
    
    

    }
}
