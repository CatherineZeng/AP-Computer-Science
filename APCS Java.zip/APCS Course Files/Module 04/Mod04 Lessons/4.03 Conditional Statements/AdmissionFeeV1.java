
/**
 * This program calculates the admission fee based on a person's age.
 * 
 * �FLVS 2007
 * @author Bill Jordan 
 * @version 03/16/07
 */
import java.util.Scanner;                                       //import the Scanner class
public class AdmissionFeeV1                                       //class declaration
{
    public static void main(String [] args)                     //beginning of main method
    {
        
String str= "supercalifragilisticexpealidocious";


System.out.println(4+5/2);
        
       
       }                                                        //end of main method
    }                                                           //end of class
