
/**
 * Write a description of class HelloWorldV2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelloWorldV2
{
    //print two lines of text
    public static void printTwoLines()
    {
        System.out.println("Hello,Virtual World!");
        System.out.println("It is a great day for programming.");
    }
    //main method
    public static void main(String[]args)
    {
        printTwoLines();
    }
}