
/**
 * Write a description of class sd here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Restock
{
   public static void main(String[] args)
   {
       int[] p={1, 2, 3}; 
       int i = 0; 

    while ( i < p[ 0 ].length ) 
    { 
      p[ 0 ][ i ] = 0; 
      i++; 
    } 
   }//end of main method
}//end of class