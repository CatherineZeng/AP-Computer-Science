
/**
 * Write a description of class Calculatable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Calculatable
{
   void calcRectangleArea();
   void calcRectanglePerimeter();
}
