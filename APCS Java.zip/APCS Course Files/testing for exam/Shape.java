
/**
 * Write a description of class hi here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class SomeClass extends SomeOtherClass 
{ 

public void convertMinutes(double minutes) 
{ 
//some code here 
} 

public void convertYears(double years) 
{ 
//some code here 
} 

} 

