
/**
 * Write a description of class asd here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InitializingNumericgArray 
{ 
 public static void main(String [] args) 
 { 
 double [] doubleValues; 
 doubleValues = new double[10]; 
 
 for(int n = 0; n <= 9; n++) 
 { 
 System.out.println("index position " + n + " = " 
 + doubleValues[n]); 
 } 
 } 
} 
