
/**
 * Creates equilateral triangle
 * 
 * @Catherine Zeng
 * @1/11/14
 */
public class Equilateral extends Triangle
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Equilateral
     */
    public Equilateral(double A)
    {
        // initialise instance variables
        super(A,A,A);
    }

}
