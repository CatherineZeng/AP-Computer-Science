
/**
 * Creates cube
 * 
 * @Catherine Zeng
 * @1/10/14
 */
public class Cube extends Box
{
    // instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Cube
     */
    public Cube(int l)
    {
        // initialise instance variables
        super(l,l,l);
    }
    

}
