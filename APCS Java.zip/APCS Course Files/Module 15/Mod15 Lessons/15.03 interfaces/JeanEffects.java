

/**

 * interface JeanEffects

 * 

 * �FLVS 2007

 * @author R. Enger 

 * @version 5/10/2007

 */



public interface JeanEffects

{

	public abstract void fadeJeans();

	public abstract void addHoles();

}

