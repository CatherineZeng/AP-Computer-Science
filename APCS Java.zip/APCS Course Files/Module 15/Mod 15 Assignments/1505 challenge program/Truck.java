
/**
 * Truck class
 * 
 * @Catherine Zeng
 * @3-12-14
 */
public class Truck extends Vehicle
{
    public Truck(String name, double cost)
    {
       super(name,cost);
    }
    
}
