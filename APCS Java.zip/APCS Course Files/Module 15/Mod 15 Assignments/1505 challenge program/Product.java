
/**
 * Product interface
 * 
 * @Catherine Zeng
 * @3-12-14
 */
public interface Product
{
   String getName();
   double getCost();
}
