
/**
 * Interface processing
 * 
 * @Catherine Zeng
 * @3-8-14
 */
public interface Processing
{
    void doReading();
}
